﻿using System;
using System.Collections.Generic;

namespace Assessment_Test
{
	public interface Entity
	{
		void Call();
		string Name{get;}
	}
}

