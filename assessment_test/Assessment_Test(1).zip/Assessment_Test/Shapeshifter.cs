﻿using System;
using System.Collections.Generic;

namespace Assessment_Test
{
	public class Shapeshifter
	{
		private Entity _device;
		private Boolean _deployed;
		private  List<Entity> _gadgets=new List<Entity>();


		public Shapeshifter ()
		{
			_deployed = false;
		}

		public Boolean Melded
		{
			get{
				return ( _gadgets.Count!=0);
			}
		}

		public void Meld(Entity gadget)
		{
			_gadgets.Add (gadget);
			_device = gadget;
		}


		public void Shift(bool flag)
		{
			if (flag)
				_deployed = true;
			else
				_deployed = false;

		}



		public void Call()
		{
		if (_device!=null && _deployed== true) {
			_device.Call();
			} else {
			Console.WriteLine ("Hi There");
			}
		}

		public void GadgetAttached()
		{
			foreach (Entity gadget in _gadgets) {
				Console.WriteLine (gadget.Name);
			}
		}

//		public void Shift(string name)
//		{
//			foreach (Entity gadget in _gadgets) {
//				if (gadget.Name == name) {
//					_device = gadget;
//					_deployed = true;
//				}
//				else {
//					_deployed = false;
//				}
//			}
//		}

//		public void Shift()
//		{
//			_deployed = false;
//		}
	}
}


